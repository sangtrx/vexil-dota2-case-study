# Live Dota 2 Win Probability

**Vexil Capital · Senior Data Scientist take-home · Truong Quang Sang**

A reproducible study of **500 parsed professional OpenDota matches** (patches 59 and 60, 21–26 March 2026). At each admissible game minute, the notebook estimates Radiant's probability of winning using information timestamped no later than that minute. This is a historical point-in-time exercise, not a live-feed latency or betting-profitability claim.

**Review in this order:** [four-page report](REPORT.pdf) → [notebook with saved outputs](live_dota2_win_probability.ipynb) → [research decision trail](docs/RESEARCH_DECISION_TRAIL.md) → [frozen TEST predictions](artifacts/heldout_predictions.csv). The original research Git ancestry is preserved in this repository, with exploratory branch heads mirrored for review; no separate source access is needed to audit the main numerical results.

## Results on the held-out TEST

| Proper score (lower is better) | Gold-only logistic M0 | Gold + time logistic M1 |
| --- | ---: | ---: |
| Validation log loss, 103 games | 0.5325 | **0.5197** |
| TEST log loss, 106 games | 0.5164 | **0.5040** |
| TEST Brier, 106 games | 0.1719 | **0.1684** |
| TEST minute-30+ Brier | **0.1028** | 0.1074 |

**Evaluation boundary:** The 12 terminal-minute corrections were made after the original TEST had been inspected. These are corrected results on the same games, **not a new blind TEST**.

The gold-only logistic model is the required baseline. I selected M1 on validation log loss; M1 adds elapsed minute and gold × time interaction to that baseline. A constant **TRAIN-only** Radiant-win prior (149/291 games) has TEST log loss **0.6884** and Brier **0.2476**, so both fitted models outperform this no-skill reference.

The primary **whole-match paired** 95% bootstrap intervals for M1 minus M0 are **[-0.0304, +0.0014]** (log loss) and **[-0.0069, +0.0002]** (Brier): both cross zero. M1's minute-30+ Brier point estimate is **0.00455 worse**, paired interval **[−0.0037,+0.0109]**. One 55-row game accounts for 54.9% of the observed gain; five embargoed TRAIN-only rolling-origin folds favored M1 in only **2/5**. **Decision: M0 remains the reference; M1 is shadow-only, not proven superior.**

The fixed-gold forecast contrast is not proof that gold is intrinsically less discriminative later. M1 maps +2,000 Radiant gold to 66.5% at minute 10 and 59.4% at minute 30, but its TRAIN-only interval crosses zero. The stronger **gold + time without an interaction** model was not reliably beaten on TRAIN-only forward blocks (M1−null log loss −0.0020, 70-series CI [−0.0148,+0.0090]); this and the [reproducible maturity-label audit](docs/DEVELOPMENT_MATURITY_AND_CREATIVE_NULL.md) explicitly bound the creative claim.

## Where the assignment requirements are addressed

| Requirement | Evidence in this package |
| --- | --- |
| 500 professional OpenDota matches | Notebook collection and frozen 250/250 match IDs; setup needs no API key |
| Gold-lead logistic baseline **and** own model | M0–M3 model comparison in notebook and [report](REPORT.pdf); M1 selected by validation |
| Information available at the forecast time | Minute-prefix features and timestamps; later [full 18,292-snapshot future-deletion audit](docs/FULL_500_PREFIX_AUDIT_RECEIPT.json) (author raw cache needed); strict pre-terminal 60*t < duration |
| Chronological split, label timing and probability evaluation | Series-disjoint **291 TRAIN / 103 VALIDATION / 106 TEST**; [offline label-maturity refit](docs/DEVELOPMENT_MATURITY_AND_CREATIVE_NULL.md) verifies M1 selection after excluding 5 unfinished TRAIN games; grouped proper scores/calibration diagnostics |
| Executable notebook with visible outputs | [Executed notebook](live_dota2_win_probability.ipynb): **16 saved-output code cells** (14 original source-frozen science + 2 post-hoc QA cells), four embedded figures; original 14-cell Colab and new 16-cell local replay receipts |
| Setup and reproducibility | [Pinned dependencies](requirements.txt), commands below, [3-minute review guide](SUBMISSION_PACKAGE_README.md), frozen forecast CSV |
| Separate report, at most four pages, with assistance disclosure | [REPORT.pdf](REPORT.pdf): four A4 pages, results, limitations, active-time estimate, AI/public-code disclosure |

## Reproduce

**Google Colab:** Upload the notebook to a CPU runtime with Internet and choose Runtime → Run all. It fetches **500 preselected, frozen match IDs through /matches/{match_id}**; this deterministic replay intentionally **does not call /proMatches** again. The original label-blind patch-boundary discovery/pagination logic using /proMatches is in the same notebook but is not the default replay path. Only these two OpenDota endpoints are permitted; rate limits are retried without replacing cohort IDs. Saved outputs and figures are available without rerunning.

**Local Python 3.12 (verified with exact pins):**

~~~bash
python3.12 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
jupyter notebook live_dota2_win_probability.ipynb
~~~

Run the notebook top to bottom. For a fast no-network contract check:

~~~bash
python -m unittest discover -s tests -p "test_*.py" -q
~~~

This runs **127 offline checks** on immutable forecasts, point-in-time logic, numerical audits and delivery integrity. From the ZIP, reviewers can rerun the notebook **with OpenDota Internet access** or recompute/check the supplied TEST forecasts **offline**. Raw OpenDota JSON is not bundled; the cached-source full replay is an author-controlled receipt, not a locally runnable ZIP-only replay. The [16-cell fresh-kernel appendix receipt](docs/REVIEWER_APPENDIX_FRESH_KERNEL_RECEIPT.json) verifies the current reviewer notebook from the original cached 500 games and recomputes PIT/no-skill/calibration/strong-null figures in memory, with no network. The archived [original 14-cell replay](docs/FULL_NOTEBOOK_REPLAY_RECEIPT.json) and [Colab cold-run receipt](docs/COLAB_COLD_RUN_RECEIPT.json) prove the frozen 3,836 TEST predictions and rounded cloud numerical parity, **not** cloud-export CSV byte parity or a separate cloud run of the two new appendix cells.

## Evidence boundaries and research history

The training split already contains 41 patch-60 games; VALIDATION and TEST are both patch 60, **not an unseen-patch generalization result**. The notebook uses API event timestamps, which do not establish when a live consumer actually received each event. Calibration-in-the-large and ECE intervals are post-hoc, not calibration fits. The original **VALIDATION** M1 forecast-minus-outcome bias is **+0.0300** (53-series CI [−0.0436,+0.1001]); on inspected **TEST** it is **−0.0617** (54-series CI [−0.1410,+0.0250]). Neither establishes drift; the [frozen validation/TEST calibration audit](docs/CALIBRATION_BIAS_READOUT.md) and [10-bin grouped reliability intervals](docs/CALIBRATION_FIXED_BIN_GROUPED_CI.md) are reproducible from bundled CSVs without any calibration fit.

An optional [100-game November check](docs/FORWARD_100_STRESS.md) uses the original frozen M0/M1 and has confidence intervals crossing zero; **68 of those games overlap an earlier 120-game research cohort**, so the results are not independent replications. [Frozen calibration audit](docs/CALIBRATION_BIAS_READOUT.md), [error analysis](docs/ERROR_ANALYSIS.md) and [experiment register](docs/EXPERIMENT_REGISTER.md) preserve negative results without model promotion.

**Git provenance:** [HISTORY.md](HISTORY.md), the [clickable branch/PR map](docs/REVIEWER_HISTORY_MAP.md) and [curation provenance](docs/CURATION_PROVENANCE.md) distinguish authentic 13–15 November research from the 16 November reviewer curation PRs. The [decision trail](docs/RESEARCH_DECISION_TRAIL.md) links hypotheses, rejected alternatives and the deployment gate to source evidence. Original GitHub PR discussions remain in a separately private repo, but original code ancestry and selected branch heads are included here. Historical 200-game raw payloads are not bundled.

The report states the candidate's **approximately 10 hours of active work** estimate and details extensive AI assistance. No third-party Dota predictor was copied; no measured betting returns or verified live latency are claimed.
